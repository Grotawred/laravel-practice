<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello World</title>
</head>
<body>
    <h1><?php echo e($text); ?></h1>
</body>
</html>
<?php /**PATH /Users/grishavlasko/Documents/IT/php/helloWorld/resources/views/hello_index.blade.php ENDPATH**/ ?>